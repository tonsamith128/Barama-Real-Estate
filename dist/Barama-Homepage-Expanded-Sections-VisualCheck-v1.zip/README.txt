Barama Real Estate — Homepage Expanded Sections Visual Check v1

Canonical main:
e9b5a171caed097f5451f2afab28ceef534c0363

PR #16 target:
2945d6c06f506e3ad20949a30751d86d8a8b4ebc

Production patch Git blob:
4b70490de23d591846646fcf3e0cecb39438645c

Scope:
- Featured Locations — OFF by default
- How It Works — OFF by default
- Trust & Stats — OFF by default
- Testimonials — OFF by default
- Blog — OFF by default
- Subscribe — OFF by default
- compact Configure footer Save icons
- newsletter subscriber migration 0021
- newsletter schema + behavior smoke tests

No Nginx changes.
No service restarts.
The package excludes GitHub workflow metadata from the production patch.
