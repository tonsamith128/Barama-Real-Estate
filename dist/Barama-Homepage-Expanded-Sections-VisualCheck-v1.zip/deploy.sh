#!/usr/bin/env bash
set -Eeuo pipefail

SITE="/www/wwwroot/baramarealestate.tonsamith.com"
PHP="/www/server/php/84/bin/php"
PATCH="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/homepage-pr16.patch"
BASE_HEAD="e9b5a171caed097f5451f2afab28ceef534c0363"
TARGET_HEAD="2945d6c06f506e3ad20949a30751d86d8a8b4ebc"
EXPECTED_PATCH_BLOB="4b70490de23d591846646fcf3e0cecb39438645c"
BACKUP_ROOT="/root/barama-real-estate-backups"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
BACKUP="$BACKUP_ROOT/homepage-expanded-sections-visual-check-$STAMP"
ROLLBACK="$BACKUP/rollback.sh"
APPLIED=0

MODIFIED=(
    "application/app/Repositories/SiteContentRepository.php"
    "application/app/Services/SiteContentManagementService.php"
    "application/resources/views/home.php"
    "application/resources/views/workspace/homepage.php"
    "application/routes/web.php"
    "assets/css/app.css"
    "assets/js/app.js"
    "docs/PRE_DEMO_PAGE_AUDIT.md"
    "tools/qa.php"
    "tools/schema-smoke.php"
)

ADDED=(
    "application/app/Http/Controllers/NewsletterController.php"
    "application/app/Repositories/NewsletterSubscriberRepository.php"
    "application/app/Security/NewsletterThrottle.php"
    "application/app/Services/NewsletterSubscriptionService.php"
    "application/database/migrations/0021_create_newsletter_subscribers.php"
    "tools/newsletter-smoke.php"
)

PHP_FILES=(
    "application/app/Http/Controllers/NewsletterController.php"
    "application/app/Repositories/NewsletterSubscriberRepository.php"
    "application/app/Repositories/SiteContentRepository.php"
    "application/app/Security/NewsletterThrottle.php"
    "application/app/Services/NewsletterSubscriptionService.php"
    "application/app/Services/SiteContentManagementService.php"
    "application/database/migrations/0021_create_newsletter_subscribers.php"
    "application/resources/views/home.php"
    "application/resources/views/workspace/homepage.php"
    "application/routes/web.php"
    "tools/newsletter-smoke.php"
    "tools/qa.php"
    "tools/schema-smoke.php"
)

git_blob_sha() {
    local file="$1"
    local size
    size="$(wc -c < "$file" | tr -d '[:space:]')"
    { printf 'blob %s\0' "$size"; cat "$file"; } | sha1sum | awk '{print $1}'
}

target_matches() {
    local rel expected actual
    while IFS='|' read -r rel expected; do
        [ -f "$SITE/$rel" ] || return 1
        actual="$(git_blob_sha "$SITE/$rel")"
        [ "$actual" = "$expected" ] || return 1
    done <<'TARGET_MANIFEST'
application/app/Http/Controllers/NewsletterController.php|685385f526318e89ceec4ad8aba8009d4f0163c7
application/app/Repositories/NewsletterSubscriberRepository.php|0d955bba17d1b24c8b1b19b398b8a721c872e6f4
application/app/Repositories/SiteContentRepository.php|c7d98b3b6b3a46b52056056a8aa10a9eb0695724
application/app/Security/NewsletterThrottle.php|f6113827335fd6270bbb794aa9a085b8d8b4003c
application/app/Services/NewsletterSubscriptionService.php|c3631e43aecbca1a1e95c1c065deb43ef927d38d
application/app/Services/SiteContentManagementService.php|372e96c9356fce36fdc4372faa0f9e3434ae7d36
application/database/migrations/0021_create_newsletter_subscribers.php|8f3891d854253cf8e61a72a0a19bf8077194d764
application/resources/views/home.php|9abe031e1309b4f7544d376eb96d51ddeede69aa
application/resources/views/workspace/homepage.php|c7a609671bee96448d11908c642e5073ee640d2e
application/routes/web.php|9c8e36875c8d702d9cdea0d38ea6d521240900b8
assets/css/app.css|8733781811d5013cd056c4b8b7ec7e4b0359c600
assets/js/app.js|3730fa87e2edb32c4737a8ee09b8f85949b96dca
docs/PRE_DEMO_PAGE_AUDIT.md|f207517161ea56a6881874b5fa20698f0db4daf4
tools/newsletter-smoke.php|5359fb0d97db9117a5ccae38bcbde3e8e24424fe
tools/qa.php|fe4862c5edd381b4d4a596fc1354cd8c48be6fb2
tools/schema-smoke.php|45ff0f5dacda4fc5e025dc38a579515cefdf0356
TARGET_MANIFEST
}

rollback_on_error() {
    local code=$?
    trap - ERR
    if [ "$APPLIED" -eq 1 ] && [ -x "$ROLLBACK" ]; then
        echo
        echo "ERROR: Homepage validation failed. Running automatic rollback..."
        bash "$ROLLBACK" || true
    fi
    exit "$code"
}
trap rollback_on_error ERR

echo "============================================================"
echo " Barama Real Estate — Homepage Expanded Sections Visual Check v1"
echo " PR #16 production scope"
echo "============================================================"
echo "Site:             $SITE"
echo "Canonical main:   $BASE_HEAD"
echo "Homepage head:    $TARGET_HEAD"
echo "Migration:        0021_create_newsletter_subscribers.php"
echo "Nginx changes:    none"
echo "Service restarts: none"
echo

test "$SITE" = "/www/wwwroot/baramarealestate.tonsamith.com" || {
    echo "ERROR: Unexpected site path."
    exit 1
}
test -d "$SITE/application" || {
    echo "ERROR: Application directory is missing."
    exit 1
}
test -x "$PHP" || {
    echo "ERROR: PHP CLI not found: $PHP"
    exit 1
}
test -f "$PATCH" || {
    echo "ERROR: Packaged patch is missing."
    exit 1
}

echo "[1/11] Checking for already-applied source target..."
if target_matches; then
    echo "Target source is already present. Skipping source patch."
else
    echo "Target source is not yet present."

    echo
    echo "[2/11] Verifying exact canonical live baseline..."
    while IFS='|' read -r rel expected; do
        test -f "$SITE/$rel" || {
            echo "ERROR: Baseline file is missing: $rel"
            exit 1
        }
        actual="$(git_blob_sha "$SITE/$rel")"
        [ "$actual" = "$expected" ] || {
            echo "ERROR: Baseline drift detected: $rel"
            echo "Expected Git blob: $expected"
            echo "Actual Git blob:   $actual"
            exit 1
        }
    done <<'BASELINE_MANIFEST'
application/app/Repositories/SiteContentRepository.php|ae85b34fe19a10dfc457c6c736ea082e6356834c
application/app/Services/SiteContentManagementService.php|3b7a0a5c22ceddf7440e186619aff108996b4d8e
application/resources/views/home.php|f5477cd8fa46e3a6ac0ae5a952f65fbfad220027
application/resources/views/workspace/homepage.php|c7422602d729521388f344ca70f95cd697d9ac35
application/routes/web.php|712cb5143c4a07ba96cf342334633df1e932d9e8
assets/css/app.css|f8b016a45c544facebda1f2d2b84878687a64d06
assets/js/app.js|06f3b6abf45740e19c8cc54fbb9e3f99e7ee8abc
docs/PRE_DEMO_PAGE_AUDIT.md|c5c9cd519f65ce82264a6f1d50c68377c0a7af34
tools/qa.php|75b777bf16d068ca7081b9aebe8fe42bd62cdb60
tools/schema-smoke.php|1c5f6a0271519173cfe348de70218931a65de9b1
BASELINE_MANIFEST

    for rel in "${ADDED[@]}"; do
        [ ! -e "$SITE/$rel" ] || {
            echo "ERROR: New PR #16 path already exists unexpectedly: $rel"
            exit 1
        }
    done
    echo "Baseline verification: PASS"

    echo
    echo "[3/11] Verifying packaged PR #16 patch identity..."
    actual_patch_blob="$(git_blob_sha "$PATCH")"
    echo "Expected patch blob: $EXPECTED_PATCH_BLOB"
    echo "Actual patch blob:   $actual_patch_blob"
    [ "$actual_patch_blob" = "$EXPECTED_PATCH_BLOB" ] || {
        echo "ERROR: Packaged patch identity mismatch."
        exit 1
    }

    echo
    echo "[4/11] Dry-running production patch with zero fuzz..."
    (
        cd "$SITE"
        patch --dry-run --batch --forward --fuzz=0 -p1 < "$PATCH"
    )
    echo "Patch dry-run: PASS"

    echo
    echo "[5/11] Creating exact pre-deploy source backup..."
    mkdir -p "$BACKUP"
    tar -C "$SITE" -czf "$BACKUP/files.tar.gz" "${MODIFIED[@]}"

    cat > "$BACKUP/rollback-newsletter.php" <<'ROLLBACK_PHP'
<?php
declare(strict_types=1);

use Barama\Core\Database;

define('BARAMA_CLI', true);
$site = '/www/wwwroot/baramarealestate.tonsamith.com';
require $site . '/application/bootstrap/app.php';

$pdo = Database::connection();
$table = $pdo->query("SHOW TABLES LIKE 'newsletter_subscribers'")->fetchColumn();

if ($table !== 'newsletter_subscribers') {
    fwrite(STDOUT, "Newsletter rollback: table is not present.\n");
    exit(0);
}

$count = (int) $pdo->query('SELECT COUNT(*) FROM newsletter_subscribers')->fetchColumn();

if ($count > 0) {
    fwrite(
        STDOUT,
        "Newsletter rollback: preserving additive table because it contains {$count} subscriber row(s).\n"
    );
    exit(0);
}

$pdo->exec('DROP TABLE newsletter_subscribers');
$statement = $pdo->prepare(
    'DELETE FROM schema_migrations WHERE migration = :migration'
);
$statement->execute([
    'migration' => '0021_create_newsletter_subscribers.php',
]);

fwrite(STDOUT, "Newsletter rollback: empty additive table and migration record removed.\n");
ROLLBACK_PHP

    cat > "$ROLLBACK" <<'ROLLBACK_SCRIPT'
#!/usr/bin/env bash
set -Eeuo pipefail

SITE="/www/wwwroot/baramarealestate.tonsamith.com"
PHP="/www/server/php/84/bin/php"
BACKUP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

test -f "$BACKUP_DIR/files.tar.gz" || {
    echo "ERROR: Backup archive missing."
    exit 1
}

rm -f \
    "$SITE/application/app/Http/Controllers/NewsletterController.php" \
    "$SITE/application/app/Repositories/NewsletterSubscriberRepository.php" \
    "$SITE/application/app/Security/NewsletterThrottle.php" \
    "$SITE/application/app/Services/NewsletterSubscriptionService.php" \
    "$SITE/application/database/migrations/0021_create_newsletter_subscribers.php" \
    "$SITE/tools/newsletter-smoke.php" \
    /dev/null 2>/dev/null || true

tar -xzf "$BACKUP_DIR/files.tar.gz" -C "$SITE"

if [ -f "$BACKUP_DIR/rollback-newsletter.php" ]; then
    "$PHP" "$BACKUP_DIR/rollback-newsletter.php"
fi

touch \
    "$SITE/application/app/Repositories/SiteContentRepository.php" \
    "$SITE/application/app/Services/SiteContentManagementService.php" \
    "$SITE/application/resources/views/home.php" \
    "$SITE/application/resources/views/workspace/homepage.php" \
    "$SITE/application/routes/web.php" \
    "$SITE/tools/qa.php" \
    "$SITE/tools/schema-smoke.php" \
    /dev/null 2>/dev/null || true

echo "Homepage Expanded Sections source rollback: PASS"
ROLLBACK_SCRIPT
    chmod +x "$ROLLBACK"

    echo "Backup:   $BACKUP"
    echo "Rollback: $ROLLBACK"

    echo
    echo "[6/11] Applying PR #16 production patch..."
    APPLIED=1
    (
        cd "$SITE"
        patch --batch --forward --fuzz=0 -p1 < "$PATCH"
    )
fi

echo
echo "[7/11] PHP syntax checks..."
for rel in "${PHP_FILES[@]}"; do
    "$PHP" -l "$SITE/$rel"
done

echo
echo "[8/11] Applying pending additive migration..."
"$PHP" "$SITE/tools/migrate.php"

echo
echo "[9/11] Running schema and newsletter smoke tests..."
"$PHP" "$SITE/tools/schema-smoke.php"
"$PHP" "$SITE/tools/newsletter-smoke.php"

echo
echo "[10/11] Verifying exact target blobs and Homepage markers..."
while IFS='|' read -r rel expected; do
    test -f "$SITE/$rel" || {
        echo "ERROR: Target file is missing: $rel"
        exit 1
    }
    actual="$(git_blob_sha "$SITE/$rel")"
    [ "$actual" = "$expected" ] || {
        echo "ERROR: Target Git blob mismatch: $rel"
        echo "Expected: $expected"
        echo "Actual:   $actual"
        exit 1
    }
done <<'TARGET_MANIFEST'
application/app/Http/Controllers/NewsletterController.php|685385f526318e89ceec4ad8aba8009d4f0163c7
application/app/Repositories/NewsletterSubscriberRepository.php|0d955bba17d1b24c8b1b19b398b8a721c872e6f4
application/app/Repositories/SiteContentRepository.php|c7d98b3b6b3a46b52056056a8aa10a9eb0695724
application/app/Security/NewsletterThrottle.php|f6113827335fd6270bbb794aa9a085b8d8b4003c
application/app/Services/NewsletterSubscriptionService.php|c3631e43aecbca1a1e95c1c065deb43ef927d38d
application/app/Services/SiteContentManagementService.php|372e96c9356fce36fdc4372faa0f9e3434ae7d36
application/database/migrations/0021_create_newsletter_subscribers.php|8f3891d854253cf8e61a72a0a19bf8077194d764
application/resources/views/home.php|9abe031e1309b4f7544d376eb96d51ddeede69aa
application/resources/views/workspace/homepage.php|c7a609671bee96448d11908c642e5073ee640d2e
application/routes/web.php|9c8e36875c8d702d9cdea0d38ea6d521240900b8
assets/css/app.css|8733781811d5013cd056c4b8b7ec7e4b0359c600
assets/js/app.js|3730fa87e2edb32c4737a8ee09b8f85949b96dca
docs/PRE_DEMO_PAGE_AUDIT.md|f207517161ea56a6881874b5fa20698f0db4daf4
tools/newsletter-smoke.php|5359fb0d97db9117a5ccae38bcbde3e8e24424fe
tools/qa.php|fe4862c5edd381b4d4a596fc1354cd8c48be6fb2
tools/schema-smoke.php|45ff0f5dacda4fc5e025dc38a579515cefdf0356
TARGET_MANIFEST

grep -Fq "'testimonials'" "$SITE/application/app/Repositories/SiteContentRepository.php"
grep -Fq "'blog'" "$SITE/application/app/Repositories/SiteContentRepository.php"
grep -Fq "'subscribe'" "$SITE/application/app/Repositories/SiteContentRepository.php"
grep -Fq "'featured_locations'" "$SITE/application/app/Repositories/SiteContentRepository.php"
grep -Fq "'how_it_works'" "$SITE/application/app/Repositories/SiteContentRepository.php"
grep -Fq "'trust_stats'" "$SITE/application/app/Repositories/SiteContentRepository.php"
grep -Fq "/subscribe" "$SITE/application/routes/web.php"
grep -Fq "BARAMA_HOMEPAGE_EXPANDED_SECTIONS_V100" "$SITE/assets/css/app.css"
grep -Fq ".config-dialog__footer .btn svg" "$SITE/assets/css/app.css"
grep -Fq "BARAMA_HOMEPAGE_SUBSCRIBE_V100" "$SITE/assets/js/app.js"

"$PHP" -r '
define("BARAMA_CLI", true);
require "/www/wwwroot/baramarealestate.tonsamith.com/application/bootstrap/app.php";
$pdo = \Barama\Core\Database::connection();
$applied = $pdo->prepare("SELECT COUNT(*) FROM schema_migrations WHERE migration = :migration");
$applied->execute(["migration" => "0021_create_newsletter_subscribers.php"]);
if ((int) $applied->fetchColumn() !== 1) { fwrite(STDERR, "Migration 0021 is not recorded.\n"); exit(1); }
$table = $pdo->query("SHOW TABLES LIKE \"newsletter_subscribers\"")->fetchColumn();
if ($table !== "newsletter_subscribers") { fwrite(STDERR, "newsletter_subscribers table is missing.\n"); exit(1); }
fwrite(STDOUT, "Migration 0021 verification: PASS\n");
'

echo "Target source/function verification: PASS"

echo
echo "[11/11] Refreshing PHP mtimes and HTTP smoke checks..."
for rel in "${PHP_FILES[@]}"; do
    touch "$SITE/$rel"
done

homepage_code="$(curl -sS -o /dev/null -w '%{http_code}' 'https://baramarealestate.tonsamith.com/')"
admin_code="$(curl -sS --max-redirs 0 -o /dev/null -w '%{http_code}' 'https://baramarealestate.tonsamith.com/dashboard/homepage' || true)"
css_code="$(curl -sS -o /dev/null -w '%{http_code}' 'https://baramarealestate.tonsamith.com/assets/css/app.css')"
js_code="$(curl -sS -o /dev/null -w '%{http_code}' 'https://baramarealestate.tonsamith.com/assets/js/app.js')"

echo "Homepage:             $homepage_code"
echo "Admin Homepage guest: $admin_code"
echo "Canonical app.css:    $css_code"
echo "Canonical app.js:     $js_code"

[ "$homepage_code" = "200" ]
[ "$admin_code" = "302" ]
[ "$css_code" = "200" ]
[ "$js_code" = "200" ]

APPLIED=0
trap - ERR

echo
echo "============================================================"
echo " HOMEPAGE EXPANDED SECTIONS VISUAL CHECK: PASS"
echo "============================================================"
echo "GitHub main base:     $BASE_HEAD"
echo "PR #16 target:        $TARGET_HEAD"
echo "New sections:         Featured Locations, How It Works,"
echo "                      Trust & Stats, Testimonials, Blog, Subscribe"
echo "Default state:        all six new sections OFF"
echo "Save icon repair:     compact dialog footer SVG"
echo "Migration:            0021 applied"
echo "Nginx changes:        none"
echo "Service restart:      none"
if [ -d "$BACKUP" ]; then
    echo "Backup:               $BACKUP"
    echo "Rollback:             $ROLLBACK"
fi
echo
echo "Visual URLs:"
echo "  https://baramarealestate.tonsamith.com/dashboard/homepage"
echo "  https://baramarealestate.tonsamith.com/"
echo
echo "Recommended check:"
echo "  1. Confirm six new rows are OFF."
echo "  2. Open Hero Configure and confirm the Save icon is compact."
echo "  3. Configure and enable one new section at a time."
echo "  4. Enable Subscribe last and submit one test email."
echo "  5. Check Light/Dark and mobile-width rendering."
echo
echo "Please paste the complete output back into ChatGPT."
