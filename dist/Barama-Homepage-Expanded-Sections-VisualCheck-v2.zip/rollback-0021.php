<?php
declare(strict_types=1);

use Barama\Core\Database;

define('BARAMA_CLI', true);

$site = '/www/wwwroot/baramarealestate.tonsamith.com';
require $site . '/application/bootstrap/app.php';

$pdo = Database::connection();
$table = $pdo->query(
    "SHOW TABLES LIKE 'newsletter_subscribers'"
)->fetchColumn();

if ($table !== 'newsletter_subscribers') {
    fwrite(STDOUT, "Newsletter rollback: table is not present.\n");
    exit(0);
}

$count = (int) $pdo->query(
    'SELECT COUNT(*) FROM newsletter_subscribers'
)->fetchColumn();

if ($count > 0) {
    fwrite(
        STDOUT,
        "Newsletter rollback: preserving table because it contains {$count} subscriber row(s).\n"
    );
    exit(0);
}

$pdo->exec('DROP TABLE newsletter_subscribers');

$delete = $pdo->prepare(
    'DELETE FROM schema_migrations WHERE migration = :migration'
);
$delete->execute([
    'migration' => '0021_create_newsletter_subscribers.php',
]);

fwrite(STDOUT, "Newsletter rollback: empty table and migration record removed.\n");
