Barama Real Estate — Homepage Expanded Sections Visual Check v2

Fixes v1 packaging assumption:
production does not require repository-only .github, tools, or docs files.

Canonical main: e9b5a171caed097f5451f2afab28ceef534c0363
PR #16 target: 2945d6c06f506e3ad20949a30751d86d8a8b4ebc
Runtime patch Git blob: 9718b8e084339371a769c988132636543d17d11b

Runtime deployment:
- 12 application/assets files
- migration 0021
- package-local migration/schema/newsletter verification
- six new Homepage sections OFF by default
- compact Configure Save icons
- no Nginx changes
- no service restart
