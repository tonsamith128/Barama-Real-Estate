<?php
declare(strict_types=1);

use Barama\Core\Database;
use RuntimeException;
use Throwable;

define('BARAMA_CLI', true);

$site = '/www/wwwroot/baramarealestate.tonsamith.com';
require $site . '/application/bootstrap/app.php';

$pdo = Database::connection();

$pdo->exec(<<<'SQL'
CREATE TABLE IF NOT EXISTS schema_migrations (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    migration VARCHAR(191) NOT NULL,
    batch INT UNSIGNED NOT NULL,
    ran_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY schema_migrations_unique (migration),
    KEY schema_migrations_batch_index (batch)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
SQL);

$name = '0021_create_newsletter_subscribers.php';

$check = $pdo->prepare(
    'SELECT COUNT(*) FROM schema_migrations WHERE migration = :migration'
);
$check->execute(['migration' => $name]);

if ((int) $check->fetchColumn() === 1) {
    fwrite(STDOUT, "[SKIP] {$name} already applied.\n");
    exit(0);
}

$file = $site . '/application/database/migrations/' . $name;
$migration = require $file;

if (!is_callable($migration)) {
    throw new RuntimeException("Migration [{$name}] must return a callable.");
}

try {
    $migration($pdo);

    $batch = (int) $pdo->query(
        'SELECT COALESCE(MAX(batch), 0) + 1 FROM schema_migrations'
    )->fetchColumn();

    $statement = $pdo->prepare(
        'INSERT INTO schema_migrations (migration, batch) VALUES (:migration, :batch)'
    );
    $statement->execute([
        'migration' => $name,
        'batch' => $batch,
    ]);

    fwrite(STDOUT, "[MIGRATED] {$name}\n");
} catch (Throwable $exception) {
    fwrite(STDERR, "[FAILED] {$name}: {$exception->getMessage()}\n");
    exit(1);
}
