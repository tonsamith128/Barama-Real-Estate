<?php
declare(strict_types=1);

use Barama\Core\Database;
use Barama\Repositories\NewsletterSubscriberRepository;
use Barama\Services\NewsletterSubscriptionService;
use InvalidArgumentException;

define('BARAMA_CLI', true);

$site = '/www/wwwroot/baramarealestate.tonsamith.com';
require $site . '/application/bootstrap/app.php';

$pdo = Database::connection();

$table = $pdo->query(
    "SHOW TABLES LIKE 'newsletter_subscribers'"
)->fetchColumn();

if ($table !== 'newsletter_subscribers') {
    throw new RuntimeException('newsletter_subscribers table is missing.');
}

$columns = (int) $pdo->query(
    "SELECT COUNT(*)
     FROM information_schema.COLUMNS
     WHERE TABLE_SCHEMA = DATABASE()
       AND TABLE_NAME = 'newsletter_subscribers'
       AND COLUMN_NAME IN (
           'id','uuid','email','status','source',
           'subscribed_at','unsubscribed_at','created_at','updated_at'
       )"
)->fetchColumn();

if ($columns !== 9) {
    throw new RuntimeException('newsletter_subscribers schema is incomplete.');
}

$unique = (int) $pdo->query(
    "SELECT COUNT(*)
     FROM information_schema.STATISTICS
     WHERE TABLE_SCHEMA = DATABASE()
       AND TABLE_NAME = 'newsletter_subscribers'
       AND INDEX_NAME = 'newsletter_subscribers_email_unique'
       AND NON_UNIQUE = 0"
)->fetchColumn();

if ($unique !== 1) {
    throw new RuntimeException('newsletter_subscribers email unique index is missing.');
}

$migration = $pdo->prepare(
    'SELECT COUNT(*) FROM schema_migrations WHERE migration = :migration'
);
$migration->execute([
    'migration' => '0021_create_newsletter_subscribers.php',
]);

if ((int) $migration->fetchColumn() !== 1) {
    throw new RuntimeException('Migration 0021 is not recorded.');
}

$pdo->beginTransaction();

try {
    $service = new NewsletterSubscriptionService();

    $first = $service->subscribe([
        'website' => '',
        'email' => 'homepage-v2-smoke@example.test',
        'source' => 'visual-check',
    ], '127.0.0.211');

    $second = $service->subscribe([
        'website' => '',
        'email' => 'HOMEPAGE-V2-SMOKE@example.test',
        'source' => 'visual-check-repeat',
    ], '127.0.0.211');

    if ($first < 1 || $second !== $first) {
        throw new RuntimeException('Duplicate-safe newsletter subscribe check failed.');
    }

    $row = $pdo->prepare(
        'SELECT email, status, source
         FROM newsletter_subscribers
         WHERE id = :id LIMIT 1'
    );
    $row->execute(['id' => $first]);
    $subscriber = $row->fetch(PDO::FETCH_ASSOC);

    if (
        !is_array($subscriber)
        || $subscriber['email'] !== 'homepage-v2-smoke@example.test'
        || $subscriber['status'] !== 'active'
        || $subscriber['source'] !== 'visual-check-repeat'
    ) {
        throw new RuntimeException('Newsletter subscriber state check failed.');
    }

    $invalidRejected = false;

    try {
        $service->subscribe([
            'website' => '',
            'email' => 'invalid-email',
            'source' => 'visual-check-invalid',
        ], '127.0.0.212');
    } catch (InvalidArgumentException) {
        $invalidRejected = true;
    }

    if (!$invalidRejected) {
        throw new RuntimeException('Invalid newsletter email was not rejected.');
    }

    $pdo->rollBack();

    fwrite(
        STDOUT,
        json_encode([
            'ok' => true,
            'migration_0021_applied' => true,
            'newsletter_schema' => true,
            'duplicate_safe' => true,
            'invalid_email_rejected' => true,
            'smoke_rolled_back' => true,
        ], JSON_UNESCAPED_SLASHES) . PHP_EOL
    );
} catch (Throwable $exception) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    throw $exception;
}
