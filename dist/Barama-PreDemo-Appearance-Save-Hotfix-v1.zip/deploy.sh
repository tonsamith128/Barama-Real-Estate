#!/usr/bin/env bash
set -Eeuo pipefail

SITE="/www/wwwroot/baramarealestate.tonsamith.com"
PHP="/www/server/php/84/bin/php"
PATCH="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/appearance-save-hotfix.patch"
BASE_HEAD="d0e52ad4bb90ece118d4ad2282405f755a611e81"
TARGET_HEAD="7cbab54c45823e5a1caf2d73a3ac61dd5031eb43"
EXPECTED_PATCH_BLOB="a7389cc1bb14c29f9b3f75d3a283ba508d3bbd18"
BACKUP_ROOT="/root/barama-real-estate-backups"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
BACKUP="$BACKUP_ROOT/pre-demo-appearance-save-hotfix-$STAMP"
ROLLBACK="$BACKUP/rollback.sh"
APPLIED=0

FILES=(
    "application/app/Http/Controllers/AdminManagementController.php"
    "application/resources/views/workspace/appearance.php"
    "assets/css/app.css"
    "assets/js/app.js"
)

git_blob_sha() {
    local file="$1"
    local size
    size="$(wc -c < "$file" | tr -d '[:space:]')"
    { printf 'blob %s\0' "$size"; cat "$file"; } | sha1sum | awk '{print $1}'
}

matches_manifest() {
    local rel expected actual
    while IFS='|' read -r rel expected; do
        [ -f "$SITE/$rel" ] || return 1
        actual="$(git_blob_sha "$SITE/$rel")"
        [ "$actual" = "$expected" ] || return 1
    done
}

rollback_on_error() {
    local code=$?
    trap - ERR
    if [ "$APPLIED" -eq 1 ] && [ -x "$ROLLBACK" ]; then
        echo
        echo "ERROR: Hotfix validation failed. Running automatic rollback..."
        bash "$ROLLBACK" || true
    fi
    exit "$code"
}
trap rollback_on_error ERR

echo "============================================================"
echo " Barama Real Estate — Appearance Save Hotfix v1"
echo " Scope: PR #14 functional save repair only"
echo "============================================================"
echo "Site:             $SITE"
echo "Live base head:   $BASE_HEAD"
echo "Hotfix head:      $TARGET_HEAD"
echo "Database changes: none"
echo "Nginx changes:    none"
echo "Service restarts: none"
echo

test -d "$SITE/application" || { echo "ERROR: Site application directory missing."; exit 1; }
test -x "$PHP" || { echo "ERROR: PHP CLI missing: $PHP"; exit 1; }
test -f "$PATCH" || { echo "ERROR: Packaged patch missing."; exit 1; }

echo "[1/8] Checking for already-applied hotfix..."
if matches_manifest <<'TARGET_MANIFEST'
application/app/Http/Controllers/AdminManagementController.php|b759ce78dd385f4d2150a70a150e826b82eaf53e
application/resources/views/workspace/appearance.php|03bb8812d54ba2db7dec2e6fbd18ab81b301301f
assets/css/app.css|f8b016a45c544facebda1f2d2b84878687a64d06
assets/js/app.js|06f3b6abf45740e19c8cc54fbb9e3f99e7ee8abc
TARGET_MANIFEST
then
    echo "Hotfix target already present. Skipping patch application."
else
    echo "Hotfix not yet applied."

    echo
    echo "[2/8] Verifying current Appearance visual-check baseline..."
    while IFS='|' read -r rel expected; do
        test -f "$SITE/$rel" || { echo "ERROR: Missing baseline file: $rel"; exit 1; }
        actual="$(git_blob_sha "$SITE/$rel")"
        [ "$actual" = "$expected" ] || {
            echo "ERROR: Baseline drift detected: $rel"
            echo "Expected Git blob: $expected"
            echo "Actual Git blob:   $actual"
            exit 1
        }
    done <<'BASE_MANIFEST'
application/app/Http/Controllers/AdminManagementController.php|7607df4526046ca52804661eb0d8f2d10e33b172
application/resources/views/workspace/appearance.php|f45e65735e190bfb6ea239fcdcbd7a480abf782a
assets/css/app.css|43fc279063d336e81bfae60162594c384365fcb4
assets/js/app.js|72473cdf07965484ee747dc27f80695f52967a01
BASE_MANIFEST
    echo "Baseline verification: PASS"

    echo
    echo "[3/8] Verifying hotfix patch identity..."
    actual_patch_blob="$(git_blob_sha "$PATCH")"
    echo "Expected patch blob: $EXPECTED_PATCH_BLOB"
    echo "Actual patch blob:   $actual_patch_blob"
    [ "$actual_patch_blob" = "$EXPECTED_PATCH_BLOB" ] || {
        echo "ERROR: Patch identity mismatch."
        exit 1
    }

    echo
    echo "[4/8] Dry-running four-file patch with zero fuzz..."
    (
        cd "$SITE"
        patch --dry-run --batch --forward --fuzz=0 -p1 < "$PATCH"
    )
    echo "Patch dry-run: PASS"

    echo
    echo "[5/8] Creating exact pre-hotfix backup..."
    mkdir -p "$BACKUP"
    tar -C "$SITE" -czf "$BACKUP/files.tar.gz" "${FILES[@]}"

    cat > "$ROLLBACK" <<'ROLLBACK_SCRIPT'
#!/usr/bin/env bash
set -Eeuo pipefail
SITE="/www/wwwroot/baramarealestate.tonsamith.com"
BACKUP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
test -f "$BACKUP_DIR/files.tar.gz" || { echo "ERROR: Backup archive missing."; exit 1; }
tar -xzf "$BACKUP_DIR/files.tar.gz" -C "$SITE"
touch   "$SITE/application/app/Http/Controllers/AdminManagementController.php"   "$SITE/application/resources/views/workspace/appearance.php"
echo "Appearance Save Hotfix rollback: PASS"
ROLLBACK_SCRIPT
    chmod +x "$ROLLBACK"
    echo "Backup:   $BACKUP"
    echo "Rollback: $ROLLBACK"

    echo
    echo "[6/8] Applying Appearance Save Hotfix..."
    APPLIED=1
    (
        cd "$SITE"
        patch --batch --forward --fuzz=0 -p1 < "$PATCH"
    )
fi

echo
echo "[7/8] Syntax, target-blob, and functional-marker checks..."
"$PHP" -l "$SITE/application/app/Http/Controllers/AdminManagementController.php"
"$PHP" -l "$SITE/application/resources/views/workspace/appearance.php"

while IFS='|' read -r rel expected; do
    actual="$(git_blob_sha "$SITE/$rel")"
    [ "$actual" = "$expected" ] || {
        echo "ERROR: Target blob mismatch: $rel"
        echo "Expected: $expected"
        echo "Actual:   $actual"
        exit 1
    }
done <<'TARGET_MANIFEST'
application/app/Http/Controllers/AdminManagementController.php|b759ce78dd385f4d2150a70a150e826b82eaf53e
application/resources/views/workspace/appearance.php|03bb8812d54ba2db7dec2e6fbd18ab81b301301f
assets/css/app.css|f8b016a45c544facebda1f2d2b84878687a64d06
assets/js/app.js|06f3b6abf45740e19c8cc54fbb9e3f99e7ee8abc
TARGET_MANIFEST

grep -Fq "executeAppearance" "$SITE/application/app/Http/Controllers/AdminManagementController.php"
grep -Fq "data-appearance-form" "$SITE/application/resources/views/workspace/appearance.php"
grep -Fq "data-appearance-dialog-notice" "$SITE/assets/js/app.js"
grep -Fq ".config-dialog__notice" "$SITE/assets/css/app.css"
echo "Hotfix source verification: PASS"

touch   "$SITE/application/app/Http/Controllers/AdminManagementController.php"   "$SITE/application/resources/views/workspace/appearance.php"

echo
echo "[8/8] HTTP smoke checks..."
css_code="$(curl -sS -o /dev/null -w '%{http_code}' 'https://baramarealestate.tonsamith.com/appearance.css')"
js_code="$(curl -sS -o /dev/null -w '%{http_code}' 'https://baramarealestate.tonsamith.com/assets/js/app.js')"
guest_code="$(curl -sS --max-redirs 0 -o /dev/null -w '%{http_code}' 'https://baramarealestate.tonsamith.com/dashboard/appearance' || true)"
echo "Appearance stylesheet: $css_code"
echo "Canonical app.js:      $js_code"
echo "Appearance guest:      $guest_code"
[ "$css_code" = "200" ]
[ "$js_code" = "200" ]
[ "$guest_code" = "302" ]

APPLIED=0
trap - ERR

echo
echo "============================================================"
echo " APPEARANCE SAVE HOTFIX: PASS"
echo "============================================================"
echo "Scope:              4 files only"
echo "Database migration: none"
echo "Nginx changes:      none"
echo "Service restart:    none"
if [ -d "$BACKUP" ]; then
    echo "Backup:             $BACKUP"
    echo "Rollback:           $ROLLBACK"
fi
echo
echo "Retest:"
echo "  https://baramarealestate.tonsamith.com/dashboard/appearance"
echo
echo "Open Configure > Motion & Effects, click Save motion,"
echo "then test an ON/OFF switch and one other Configure dialog."
echo "Any server-side save error will now be visible inside the popup."
echo "Please paste the complete output and tell ChatGPT whether Save works."
