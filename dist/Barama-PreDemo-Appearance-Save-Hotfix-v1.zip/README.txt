Barama Real Estate — Appearance Save Hotfix v1
Base live visual-check head: d0e52ad4bb90ece118d4ad2282405f755a611e81
Hotfix target head: 7cbab54c45823e5a1caf2d73a3ac61dd5031eb43
Patch Git blob: a7389cc1bb14c29f9b3f75d3a283ba508d3bbd18

Purpose:
- dedicated Appearance submit handler
- visible in-dialog errors
- popup closes on successful save
- native POST/redirect fallback
- reset confirmation retained
- no migration, Nginx change, or service restart
