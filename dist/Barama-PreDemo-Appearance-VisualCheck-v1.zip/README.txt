Barama Real Estate — Appearance Visual Check v1

Base: 326cf76563e6bb9558ab2cb5792f0e1776a43e6a
Target PR #14: d0e52ad4bb90ece118d4ad2282405f755a611e81
Patch Git blob: b1e936a00ca7d8303096b4a6e6fe146dc0fd4f35

Scope:
- Standalone /dashboard/appearance
- 18 configurable Appearance modules
- CSP-safe /appearance.css frontend integration
- Public + standalone auth frontend wiring
- No migration
- No Nginx change
- No service restart
- Appearance overrides OFF by default

Upload this ZIP to /root on the aaPanel server and run the command block supplied by ChatGPT.
