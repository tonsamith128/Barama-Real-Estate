#!/usr/bin/env bash
set -Eeuo pipefail

SITE="/www/wwwroot/baramarealestate.tonsamith.com"
PHP="/www/server/php/84/bin/php"
PATCH="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/appearance-pr14.patch"
BASE_COMMIT="326cf76563e6bb9558ab2cb5792f0e1776a43e6a"
TARGET_COMMIT="d0e52ad4bb90ece118d4ad2282405f755a611e81"
EXPECTED_PATCH_BLOB="b1e936a00ca7d8303096b4a6e6fe146dc0fd4f35"
BACKUP_ROOT="/root/barama-real-estate-backups"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
BACKUP="$BACKUP_ROOT/pre-demo-appearance-visual-check-$STAMP"
ROLLBACK="$BACKUP/rollback.sh"
APPLIED=0

MODIFIED=(
    "application/app/Http/Controllers/AdminManagementController.php"
    "application/app/Http/Controllers/DashboardController.php"
    "application/resources/views/layouts/app.php"
    "application/routes/web.php"
    "assets/css/app.css"
    "docs/PRE_DEMO_PAGE_AUDIT.md"
)

ADDED=(
    "application/app/Http/Controllers/AppearanceController.php"
    "application/app/Repositories/AppearanceRepository.php"
    "application/app/Services/AppearanceManagementService.php"
    "application/resources/views/workspace/appearance.php"
)

PHP_FILES=(
    "application/app/Http/Controllers/AdminManagementController.php"
    "application/app/Http/Controllers/AppearanceController.php"
    "application/app/Http/Controllers/DashboardController.php"
    "application/app/Repositories/AppearanceRepository.php"
    "application/app/Services/AppearanceManagementService.php"
    "application/resources/views/layouts/app.php"
    "application/resources/views/workspace/appearance.php"
    "application/routes/web.php"
)

git_blob_sha() {
    local file="$1"
    local size
    size="$(wc -c < "$file" | tr -d '[:space:]')"
    { printf 'blob %s\0' "$size"; cat "$file"; } | sha1sum | awk '{print $1}'
}

expect_http() {
    local label="$1"
    local url="$2"
    local expected="$3"
    local code
    code="$(curl -sS -L --max-redirs 0 -o /dev/null -w '%{http_code}' "$url" 2>/dev/null || true)"
    printf '%-28s %s\n' "$label:" "$code"
    [ "$code" = "$expected" ] || {
        echo "ERROR: $label expected HTTP $expected, received $code."
        return 1
    }
}

target_matches() {
    local rel expected actual
    while IFS='|' read -r rel expected; do
        [ -f "$SITE/$rel" ] || return 1
        actual="$(git_blob_sha "$SITE/$rel")"
        [ "$actual" = "$expected" ] || return 1
    done <<'TARGET_MANIFEST'
application/app/Http/Controllers/AdminManagementController.php|7607df4526046ca52804661eb0d8f2d10e33b172
application/app/Http/Controllers/AppearanceController.php|f245c13592cc9a6f1f4f9d4a226130c7a565f21b
application/app/Http/Controllers/DashboardController.php|3096aa08ac87ac549b824696c7e0a248d8aebde8
application/app/Repositories/AppearanceRepository.php|303155e8a371622a89aea2a29da69b7262fbf83e
application/app/Services/AppearanceManagementService.php|fe91c80398116762c0edbafc28c9962b13823d6d
application/resources/views/layouts/app.php|bddbdef7d155b5390eacec8850ff99924928c49b
application/resources/views/workspace/appearance.php|f45e65735e190bfb6ea239fcdcbd7a480abf782a
application/routes/web.php|712cb5143c4a07ba96cf342334633df1e932d9e8
assets/css/app.css|43fc279063d336e81bfae60162594c384365fcb4
docs/PRE_DEMO_PAGE_AUDIT.md|c5c9cd519f65ce82264a6f1d50c68377c0a7af34
TARGET_MANIFEST
}

rollback_on_error() {
    local code=$?
    trap - ERR
    if [ "$APPLIED" -eq 1 ] && [ -x "$ROLLBACK" ]; then
        echo
        echo "ERROR: Validation failed after source changes. Running automatic rollback..."
        bash "$ROLLBACK" || true
    fi
    exit "$code"
}
trap rollback_on_error ERR

echo "============================================================"
echo " Barama Real Estate — Appearance Visual Check v1"
echo " Scope: PR #14 only"
echo "============================================================"
echo "Site:             $SITE"
echo "Accepted base:    $BASE_COMMIT"
echo "Appearance head:  $TARGET_COMMIT"
echo "Database changes: none during deployment"
echo "Nginx changes:    none"
echo "Service restarts: none"
echo

test "$SITE" = "/www/wwwroot/baramarealestate.tonsamith.com" || {
    echo "ERROR: Unexpected site path."
    exit 1
}
test -d "$SITE/application" || {
    echo "ERROR: Barama application directory is missing."
    exit 1
}
test -x "$PHP" || {
    echo "ERROR: PHP CLI not found: $PHP"
    exit 1
}
test -f "$PATCH" || {
    echo "ERROR: Packaged patch is missing."
    exit 1
}

echo "[1/10] Checking whether the Appearance target is already deployed..."
if target_matches; then
    echo "Target source is already present. Skipping source patch."
    APPLIED=0
else
    echo "Target is not yet present."

    echo
    echo "[2/10] Verifying canonical live baseline..."
    while IFS='|' read -r rel expected; do
        test -f "$SITE/$rel" || {
            echo "ERROR: Baseline file is missing: $rel"
            exit 1
        }
        actual="$(git_blob_sha "$SITE/$rel")"
        [ "$actual" = "$expected" ] || {
            echo "ERROR: Baseline drift detected: $rel"
            echo "Expected Git blob: $expected"
            echo "Actual Git blob:   $actual"
            exit 1
        }
    done <<'BASELINE_MANIFEST'
application/app/Http/Controllers/AdminManagementController.php|4695ad8d247746bd604ecaa2dfdbe3661fc904dc
application/app/Http/Controllers/DashboardController.php|0c9390b06b34e21992845dccbca5806464ee68e2
application/resources/views/layouts/app.php|b69027fa6b0e5ca8fbab3d68ff6c75155b6a0daf
application/routes/web.php|8dd35fa360fc62e0fc15e00ecbb6f574ced4427f
assets/css/app.css|b7efd1b1c691ff849d6069a229915bf3b73b6374
docs/PRE_DEMO_PAGE_AUDIT.md|bc992f814a835631c48c3f91614e33e18a81b3ef
BASELINE_MANIFEST

    for rel in "${ADDED[@]}"; do
        [ ! -e "$SITE/$rel" ] || {
            echo "ERROR: New Appearance path already exists unexpectedly: $rel"
            exit 1
        }
    done
    echo "Baseline verification: PASS"

    echo
    echo "[3/10] Verifying packaged PR #14 patch identity..."
    actual_patch_blob="$(git_blob_sha "$PATCH")"
    echo "Expected patch blob: $EXPECTED_PATCH_BLOB"
    echo "Actual patch blob:   $actual_patch_blob"
    [ "$actual_patch_blob" = "$EXPECTED_PATCH_BLOB" ] || {
        echo "ERROR: Packaged patch identity mismatch."
        exit 1
    }

    echo
    echo "[4/10] Dry-running Appearance patch with zero fuzz..."
    (
        cd "$SITE"
        patch --dry-run --batch --forward --fuzz=0 -p1 < "$PATCH"
    )
    echo "Patch dry-run: PASS"

    echo
    echo "[5/10] Creating exact source backup..."
    mkdir -p "$BACKUP"
    tar -C "$SITE" -czf "$BACKUP/files.tar.gz" "${MODIFIED[@]}"

    cat > "$ROLLBACK" <<'ROLLBACK_SCRIPT'
#!/usr/bin/env bash
set -Eeuo pipefail
SITE="/www/wwwroot/baramarealestate.tonsamith.com"
BACKUP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

test -f "$BACKUP_DIR/files.tar.gz" || {
    echo "ERROR: Backup archive missing."
    exit 1
}

rm -f \
    "$SITE/application/app/Http/Controllers/AppearanceController.php" \
    "$SITE/application/app/Repositories/AppearanceRepository.php" \
    "$SITE/application/app/Services/AppearanceManagementService.php" \
    "$SITE/application/resources/views/workspace/appearance.php"

tar -xzf "$BACKUP_DIR/files.tar.gz" -C "$SITE"

find "$SITE/application" -type f -name '*.php' \
    \( -path '*/Http/Controllers/AdminManagementController.php' \
       -o -path '*/Http/Controllers/DashboardController.php' \
       -o -path '*/resources/views/layouts/app.php' \
       -o -path '*/routes/web.php' \) \
    -exec touch {} +

echo "Appearance visual-check source rollback: PASS"
echo "Note: Appearance settings saved later through Admin may remain as an inert"
echo "application_settings row after source rollback. Use Reset defaults before"
echo "rollback if you want that row returned to defaults."
ROLLBACK_SCRIPT
    chmod +x "$ROLLBACK"

    echo "Backup:   $BACKUP"
    echo "Rollback: $ROLLBACK"

    echo
    echo "[6/10] Applying PR #14 Appearance patch..."
    APPLIED=1
    (
        cd "$SITE"
        patch --batch --forward --fuzz=0 -p1 < "$PATCH"
    )
fi

echo
echo "[7/10] PHP syntax checks..."
for rel in "${PHP_FILES[@]}"; do
    "$PHP" -l "$SITE/$rel"
done

echo
echo "[8/10] Verifying target source blobs and feature markers..."
while IFS='|' read -r rel expected; do
    test -f "$SITE/$rel" || {
        echo "ERROR: Target file is missing: $rel"
        exit 1
    }
    actual="$(git_blob_sha "$SITE/$rel")"
    [ "$actual" = "$expected" ] || {
        echo "ERROR: Target Git blob mismatch: $rel"
        echo "Expected: $expected"
        echo "Actual:   $actual"
        exit 1
    }
done <<'TARGET_MANIFEST'
application/app/Http/Controllers/AdminManagementController.php|7607df4526046ca52804661eb0d8f2d10e33b172
application/app/Http/Controllers/AppearanceController.php|f245c13592cc9a6f1f4f9d4a226130c7a565f21b
application/app/Http/Controllers/DashboardController.php|3096aa08ac87ac549b824696c7e0a248d8aebde8
application/app/Repositories/AppearanceRepository.php|303155e8a371622a89aea2a29da69b7262fbf83e
application/app/Services/AppearanceManagementService.php|fe91c80398116762c0edbafc28c9962b13823d6d
application/resources/views/layouts/app.php|bddbdef7d155b5390eacec8850ff99924928c49b
application/resources/views/workspace/appearance.php|f45e65735e190bfb6ea239fcdcbd7a480abf782a
application/routes/web.php|712cb5143c4a07ba96cf342334633df1e932d9e8
assets/css/app.css|43fc279063d336e81bfae60162594c384365fcb4
docs/PRE_DEMO_PAGE_AUDIT.md|c5c9cd519f65ce82264a6f1d50c68377c0a7af34
TARGET_MANIFEST

grep -Fq "/dashboard/appearance" "$SITE/application/routes/web.php"
grep -Fq "AppearanceRepository" "$SITE/application/app/Http/Controllers/DashboardController.php"
grep -Fq "appearance.css?v=" "$SITE/application/resources/views/layouts/app.php"
grep -Fq "BARAMA_APPEARANCE_MANAGER_V100" "$SITE/assets/css/app.css"
grep -Fq "'typography'" "$SITE/application/app/Services/AppearanceManagementService.php"
grep -Fq "'motion'" "$SITE/application/app/Services/AppearanceManagementService.php"
echo "Target source verification: PASS"

echo
echo "[9/10] Refreshing PHP mtimes for normal PHP-FPM timestamp revalidation..."
for rel in "${PHP_FILES[@]}"; do
    touch "$SITE/$rel"
done

echo
echo "[10/10] HTTP smoke checks..."
CSS_TMP="$(mktemp)"
CSS_HEADERS="$(mktemp)"
trap 'rm -f "$CSS_TMP" "$CSS_HEADERS"' EXIT
css_code="$(curl -sS -D "$CSS_HEADERS" -o "$CSS_TMP" -w '%{http_code}' "https://baramarealestate.tonsamith.com/appearance.css")"
printf '%-28s %s\n' "Appearance stylesheet:" "$css_code"
[ "$css_code" = "200" ]
grep -qi '^Content-Type: text/css' "$CSS_HEADERS"
grep -Fq "Barama dynamic frontend appearance" "$CSS_TMP"

expect_http "Homepage" "https://baramarealestate.tonsamith.com/" "200"
expect_http "Properties" "https://baramarealestate.tonsamith.com/properties" "200"
expect_http "Projects" "https://baramarealestate.tonsamith.com/projects" "200"
expect_http "Companies" "https://baramarealestate.tonsamith.com/company" "200"
expect_http "Login" "https://baramarealestate.tonsamith.com/login" "200"
expect_http "Admin Appearance guest" "https://baramarealestate.tonsamith.com/dashboard/appearance" "302"

APPLIED=0
trap - ERR
rm -f "$CSS_TMP" "$CSS_HEADERS"
trap - EXIT

echo
echo "============================================================"
echo " APPEARANCE VISUAL CHECK DEPLOYMENT: PASS"
echo "============================================================"
echo "Source scope:       PR #14 Appearance Manager only"
echo "Appearance modules: 18 (all overrides OFF by default)"
echo "Database migration: none"
echo "Nginx changes:      none"
echo "Service restart:    none"
if [ -n "${BACKUP:-}" ] && [ -d "${BACKUP:-}" ]; then
    echo "Backup:             $BACKUP"
    echo "Rollback:           $ROLLBACK"
fi
echo
echo "Visual URLs:"
echo "  https://baramarealestate.tonsamith.com/dashboard/appearance"
echo "  https://baramarealestate.tonsamith.com/"
echo "  https://baramarealestate.tonsamith.com/properties"
echo "  https://baramarealestate.tonsamith.com/projects"
echo "  https://baramarealestate.tonsamith.com/company"
echo "  https://baramarealestate.tonsamith.com/login"
echo
echo "Test one module at a time, then verify Light/Dark on multiple frontend pages."
echo "Please paste this complete output back into ChatGPT."
